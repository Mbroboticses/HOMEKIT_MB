#define APP_NAME                "ESPURNA"
#define APP_VERSION             "1.13.4-dev"
#define APP_AUTHOR              "xose.perez@gmail.com"
#define APP_WEBSITE             "http://tinkerman.cat"
#define CFG_VERSION             3
